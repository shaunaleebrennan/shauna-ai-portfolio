# Narrative design in the age of AI

## Contents

- Five principles
- Language and differentiation checks
- Apply the lens across the five stages
- Match proof to the promise
- Thought leadership and durability

## Five principles

Build an AI narrative around a meaningful change in the audience's world and a credible way forward.

1. **Make AI language earn its place.** Explain what works differently and why it matters when using AI-native, AI-powered, agentic, or similar descriptions.
2. **Find the change beneath the technology.** Investigate behavior, expectations, work, economics, or decision-making rather than assuming a new model feature changes everything.
3. **Give people a practical role in the future.** Explain what the system handles, where human judgment matters, and how responsibilities change.
4. **Match proof to the promise.** Distinguish what is possible, what the product delivers today, and what customers have actually achieved.
5. **Contribute a point of view.** Use observation and experience to challenge an assumption and recommend a different decision. Make forecasts recognizable as forecasts.

Ask: **What will the audience understand or do differently, why should they believe it, and why should they choose this approach?**

## Language and differentiation checks

Apply an editorial removal test: temporarily remove AI and its promotional modifiers. Check whether the customer, change, value, mechanism, and reason to choose are still clear. Restore terms that provide necessary technical, product, or category information.

Use no numerical AI word quota or blanket ban. Do not substitute intelligent, smart, autonomous, or next-generation while leaving the same empty claim. Do not remove a technical explanation that matters to the buyer merely to reduce repetition.

| Term or claim | Required explanation |
| --- | --- |
| AI-native | What was designed differently, and how does that alter useful customer work? Do not treat architecture as proof of outcomes. |
| AI-powered | Which task uses AI, with what inputs and resulting benefit? |
| Agentic/autonomous | What can it decide and execute, within what scope, with which tools, permissions, review, exceptions, and intervention? Do not relabel recommendations as execution. |
| Trusted/enterprise-grade | Which specific controls, evidence, or conditions support the claim? Investigate relevant permissions, source handling, reliability, and accountability without imposing an unrelated checklist. |
| Productivity/ROI | What baseline, population, workflow, time horizon, costs, review effort, error rate, and outcome were measured? |

Distinguish **architectural novelty**, **customer value**, and **competitive differentiation**. Explain and support each separately. A shared model improvement can help every competitor; do not automatically claim durable advantage from it.

Compare with the buyer's actual alternatives: existing workflow, incumbent functionality, a general-purpose assistant, internal development, specialist tools, or doing nothing where relevant. Explain context, reach, workflow fit, integrations, permissions, implementation, or outcomes only when they create a supported difference.

## Apply the lens across the five stages

| Stage | Investigation |
| --- | --- |
| Change | Separate technical possibility, observed adoption, changing expectations, and changes in economics. Establish the links instead of treating them as an inevitable chain. |
| Impact | Specify whose work or decisions change and through what mechanism. Include groups excluded from access or benefit if that matters to this audience. |
| New Game | Explain practical behaviors, how to select suitable tasks, what remains human-owned, and how success is judged. Avoid defining the method as buying an AI product. |
| Obstacles | Investigate relevant knowledge quality, permissions, integration, reliability, economics, operating ownership, and adoption barriers. Include costs created by the new approach. |
| Solution | Explain delivered behavior and product boundaries. Separate prototypes, pilot access, configurations, integrations, roadmaps, and customer results. |

Do not assume capability → adoption → changed expectations → new operating model. Treat each connection as a claim requiring appropriate support.

## Match proof to the promise

| Evidence available | Claim it may support | Unjustified leap |
| --- | --- | --- |
| A model can perform a task in an evaluation | Performance under the reported test conditions | This product reliably performs the whole workflow |
| A product demonstration | The illustrated behavior occurred under those conditions | Reliable deployment at scale |
| A convincing answer or action recommendation | An answer or recommendation was produced | The task was executed correctly |
| A verified final state | The specified task completed under evaluated conditions | Every task or workflow succeeds |
| Time saved on an activity | Measured activity-level change | Net workflow or business productivity after checking, errors, and adoption |
| Existing platform reach or usage | Access or use of that platform | Adoption, engagement, or value from its AI feature |
| Positive customer reactions | Stated interest or perceived usefulness in the studied context | Purchase, retention, or revenue impact |
| A roadmap intention | The company's stated direction | A currently delivered or guaranteed capability |

Describe what succeeded, for whom, under what conditions, and how it was assessed. For agents, distinguish a claim in the response from the outcome in the relevant system. Consider variability, failed attempts, review burden, and exceptions when those affect the narrative claim. Do not require a full engineering evaluation to assess a headline; request or identify the evidence appropriate to its promise.

Clarify who sets objectives, supplies context, approves actions, handles exceptions, and evaluates results. Avoid implying that a human review step guarantees quality or that greater autonomy always produces greater value.

## Thought leadership and durability

Keep room for an ambitious future view. Separate:

- **Observation:** What the evidence establishes within its scope.
- **Interpretation:** What the author believes it means.
- **Prediction:** What may happen, on which assumptions and time horizon.
- **Recommendation:** What the audience should decide or prepare now, and why.

Use natural phrasing rather than mechanically labeling every sentence. Require an observation or grounded premise, a useful interpretation, a practical recommendation, a serious counterargument, and what would change the author's view. Do not invent the author's personal experience or customer observations.

Connect future ambition to present value and a credible path. Do not demand that every future prediction already be demonstrated; demand honesty about its basis and uncertainty. Avoid forcing the narrative into generic certainty to remove hype.

Run a durability check when capabilities change: does this strengthen an existing value theme, change differentiated value, change the audience/alternatives, or undermine the premise? Update examples, mechanisms, and proof when sufficient. Revisit positioning or the strategic narrative when its material foundations change. Record which change warrants which action rather than rewriting the entire story after every model release.

Use the source notes in the framework reference to locate the supporting Dunford and Anthropic material. Treat these rules as this skill's practical AI extension, not an additional stage in Andrews' framework.
