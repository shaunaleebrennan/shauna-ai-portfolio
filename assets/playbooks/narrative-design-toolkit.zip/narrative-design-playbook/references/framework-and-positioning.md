# Framework and positioning

## Contents

- Strategic diagnosis and positioning foundation
- Development workflow and story arc
- The five stages
- Category strategy and the new game
- Worked example
- Alignment and business application
- Source notes

## Strategic diagnosis and positioning foundation

Establish what the work must accomplish before writing. Use a short internal brief: objective; primary audience; buying situation; current approach; available alternatives; product reality; distinct value; evidence; constraints; decision owner when relevant.

Distinguish the disciplines while connecting their outputs:

| Discipline | Decision it supports |
| --- | --- |
| Positioning | Who should choose the product, over which alternatives, for what differentiated value, in which market context? |
| Narrative | What is changing, why does it matter, how should this audience respond, and how does the company help? |
| Category strategy | Which buying criteria or market assumptions should change, and what would it take to establish that frame? |
| Messaging | Which claims, explanations, proof, and objections carry the argument for each audience? |
| Copy and activation | How should those messages work in a particular asset, channel, or conversation? |

If positioning is unsettled, establish a provisional foundation:

1. Identify the primary audience and a concrete use or buying situation.
2. Identify what people would actually use or do without this product, including manual work, doing nothing, an incumbent, internal development, or another tool.
3. Identify capabilities that differ in a way relevant to those alternatives. Check the comparison.
4. Translate each capability into a practical value mechanism and customer outcome.
5. Identify who values those differences most and the category context that helps them understand the offer.
6. Record evidence and open decisions. Present alternative positioning hypotheses if needed rather than pretending alignment exists.

Explore trade-offs. Specify who the story will not prioritize, what the product cannot solve, and what evidence would change the recommendation. Do not use a story to conceal undifferentiated value or an unresolved product gap.

## Development workflow and story arc

Use the companion with the playbook's development workflow:

| Development stage | Practical work |
| --- | --- |
| Find the tension | Research the audience, market signals, alternatives, and accepted assumptions. |
| Define the belief shift | State the insight, its implications for buying criteria, and the decision or behavior to influence. |
| Design the narrative arc | Choose and develop a change-led or reframe-led argument; establish the approach, obstacles, product contribution, and proof. |
| Make the story usable | Adapt the core argument into messaging, examples, proof, and appropriate GTM assets. |
| Test and evolve | Investigate comprehension, relevance, credibility, intended action, and changing foundations. |

This workflow describes how to develop and use a narrative. The five stages below describe the change-led story the audience experiences.

When a persistent problem is being misunderstood and an external change is not established, use a reframe-led alternative: recognizable situation, consequential contradiction, a new interpretation, a practical approach, barriers, credible product contribution, and next action. Label it as this companion's practical synthesis, not Andrews' five-stage method. An absence of market-change evidence is a reason to choose a different arc, investigate further, or remain provisional; it is not permission to invent a trend.

Use contrast and pacing to strengthen either arc. Return to the difference between present conditions and the proposed future when useful. Do not treat presentation rhythm as another competing project workflow.

## The five stages

### 1. The Change

Identify a consequential external shift the audience can recognize. Investigate changes in behavior, expectations, economics, technology use, regulation, work, or buying conditions.

Ask what changed, compared with when, for whom, and on what evidence. Distinguish a technology becoming possible from adoption and its consequences. A shared market shift is acceptable; a distinctive story does not require inventing one.

Reject a product release masquerading as a market change, an eternal inconvenience presented as new, and an inevitable future asserted without support. If no meaningful change is established, investigate further, retain a clearly provisional hypothesis, or select the labeled reframe-led alternative when the evidence supports it. Recommend a straightforward positioning/value explanation when no broader narrative is needed.

Output one precise change statement, why now, its evidence, and its scope.

### 2. The Impact

Translate the change into the audience's responsibilities, ambitions, decisions, constraints, and risks. Explain both opportunity and cost of inaction when relevant; avoid a simplistic winners-and-losers prediction.

Ask what now becomes possible, harder, more expensive, expected, or risky. Explain the causal mechanism instead of relying on urgency words. Use an actual customer scene when available; label invented examples as illustrative.

Keep the product out of this reasoning long enough to establish why adaptation matters. Do not simply list familiar pains.

Output audience, current approach, changed stakes, and a specific implication.

### 3. The New Game

Establish a useful response before naming it. Require:

- A definition a customer can retell.
- A belief about what needs to change, and why.
- A practical method or set of behaviors.
- A fair comparison with the current approach.
- A description of success and meaningful trade-offs.
- Value independent of buying the product.

Use a simple name once the method has substance. Keep it provisional if distinctiveness, comprehension, or market use is unchecked. A generic method can still be useful; do not mislabel it original.

Ask: If the company disappeared, would the approach remain useful? Could a practitioner act on it without an additional sales pitch? What would a capable critic reject?

### 4. Why It's Hard

Ground adoption barriers in customer evidence. Consider organizational ownership, incentives, skills, behavior, budget, integration, data, permissions, workflow dependencies, implementation effort, and change management as relevant.

Distinguish existing frustrations from barriers to the proposed new approach. Recognize costs and risks the new approach creates. Do not select obstacles solely because the product happens to solve them. Acknowledge important constraints outside the product's scope.

Describe capable people working within real constraints. Avoid making the audience seem incompetent or irrational.

### 5. The Solution

Use a traceable mapping:

| Customer obstacle | Delivered capability | Practical mechanism | Outcome | Evidence and limits |
| --- | --- | --- | --- | --- |
| Name the established barrier | State what actually works | Explain how it changes the work | Specify the resulting benefit | Give the source, conditions, and gaps |

Distinguish delivered scope, configuration requirements, pilot features, integrations, and future plans. If the product only addresses part of the method, say so. Include the human, service, process, or ecosystem contribution where needed.

Establish why the product is a credible choice against actual alternatives. Do not imply it is the only possible path unless evidence supports that claim.

## Category strategy and the new game

Shape buying criteria by explaining a real change and a useful response. Do not equate a new game with a new software category.

| Choice | Appropriate consideration |
| --- | --- |
| Compete in an existing category | Use a familiar frame and explain differentiated value. |
| Reframe the approach within a category | Challenge a specific assumption and teach a useful method. |
| Advocate a new category | Establish buyer recognition, boundaries, alternatives, education requirements, resources, and leadership commitment. |

Separate authority from ownership. Earn association with an approach through useful education, methods, customer outcomes, and sustained execution. A coined phrase, manifesto, or content volume alone does not establish a moat.

Consider where the market is headed without positioning a current sales conversation against imaginary future competitors. Treat the future view as a hypothesis that informs preparation and roadmap choices.

## Worked example

Treat this example as fictional. Use it to distinguish a useful reframe from a demonstrated market change.

**Context:** Customer onboarding software coordinates requirements, responsibilities, and progress. In this illustration, AI flags missing information. None of these details establishes real-world performance or differentiation.

**Starting belief:** Onboarding is complete when the internal checklist is finished.

**Contradiction to investigate:** A team can complete its tasks while the customer is still unable to achieve the intended outcome.

**Proposed belief shift:** Organize onboarding around the customer's first valuable outcome. This could change which milestones the buyer measures and which capabilities they prioritize.

**Practical approach:** Agree the first valuable outcome with the customer, work back to the milestones that enable it, assign responsibility for each dependency, and evaluate progress toward the outcome. Investigate whether the target teams already do this well.

**Barriers to investigate:** Cross-team ownership, different definitions of completion, missing requirements, and poor visibility into customer progress. Do not present these as research findings.

**Product contribution:** Show how requirements, responsibilities, progress, and missing-information flags help a responsible person identify and address a blocker. Compare with the buyer's existing tools before claiming a differentiated advantage.

**Proof needed:** A concrete case of the contradiction; evidence the proposed approach helps in the target context; product behavior under relevant conditions; and the resulting customer outcome. Keep these forms of support distinct.

**Arc choice:** This currently supports a reframe-led story. It does not establish that customer expectations or onboarding conditions have changed over time. To use a change-led narrative, first substantiate such a shift and its implications. Never add a fictional market trend to complete the five-stage template.

## Alignment and business application

For substantial company-wide work, establish the sponsor, accountable owner, contributors, and final decision maker. Use a simple responsibility model; introduce DARCI only when it helps resolve ambiguity. Do not invent owners or require CEO participation in every campaign or asset.

Build a concise prototype, gather relevant internal and external feedback, then activate at the appropriate scale. Where sponsorship is limited, start with an authorized product or campaign scope.

Translate the narrative into choices about target segments, product priorities, launches, campaigns, education, sales proof, and buying criteria. State when a recommendation depends on a strategic choice leadership has not made.

## Source notes

Use these as methodological and supporting sources, not evidence that a particular company's narrative is effective. Recheck time-sensitive claims when reusing them.

- Marcus Andrews, [Narrative design: How to create a story people can't ignore](https://wynter.com/post/narrative-design). Foundation for the five stages and a useful new game with a practical process.
- April Dunford, [Positioning in the Age of AI](https://aprildunford.substack.com/p/positioning-in-the-age-of-ai), May 21, 2026. Supporting perspective on future vision, current alternatives, and connecting future ambition to today's value.
- April Dunford, [Shifting Positioning When AI Capabilities are Rapidly Changing](https://aprildunford.substack.com/p/shifting-positioning-when-ai-capabilities), September 3, 2026. Supporting distinction between capability changes and changes in differentiated value.
- Anthropic, [Demystifying evals for AI agents](https://www.anthropic.com/research/demystifying-evals-for-ai-agents), January 9, 2026. Supporting distinction between outputs and completed outcomes, evaluation scope, and repeated trials.
- Edelman and LinkedIn, [2025 B2B Thought Leadership Impact Report](https://www.edelman.com/sites/g/files/aatuss191/files/2025-07/2025%20Edelman-LinkedIn%20B2B%20Thought%20Leadership%20Impact%20Report_FINAL.pdf). Supporting research on the stated preferences of surveyed buyers; do not generalize it into guaranteed commercial impact.

- Marcus Andrews, [Narrative Design for Business](https://www.m3ka.com/frameworks/narrative-design). Primary guide to the change-led method and its relationship to positioning.
- Nancy Duarte, [How to move presentation audiences with structure and story](https://www.duarte.com/blog/move-presentation-audience-with-story-techniques-in-presentations/). Supporting perspective on audience transformation, contrast, and pacing.
- Donald Miller, [Your Brand Is Not the Hero](https://storybrand.com/downloads/your-brand-is-not-the-hero.pdf). Supporting perspective on customer agency and the brand's guiding role.

Credit the five-stage method to Marcus Andrews. This independent companion is authored by Shauna Azevedo-Brennan and is not an official Marcus Andrews product or a copy of his GPT. Treat its workflow mapping, reframe-led alternative, AI lens, pressure tests, numerical rubric, and operating protocols as practical extensions. Do not claim access to private course materials or hidden GPT instructions.
