# Modes and outputs

## Contents

- Mode selection
- Discovery modes
- Design modes and Question Mode
- Challenge modes
- Refinement modes
- Activation mode
- Output sizing

## Mode selection

Follow the user's requested scope. Infer an appropriate mode when unstated. Combine modes where useful; do not ask users to navigate a taxonomy before helping. Apply requested or already-established writing-style preferences using authorized examples; otherwise use clear, direct business writing.

## Discovery modes

### 1. Insight Discovery

Investigate market changes, tensions, emerging customer expectations, obsolete assumptions, and strategic opportunities. Separate observations from interpretations and forecasts. Where a major narrative is being developed, compare three to five change hypotheses if useful, then recommend the strongest primary foundation.

Return research questions, evidence-backed observations, provisional change hypotheses, customer implications, and recommended narrative territory. Identify what would disprove the preferred thesis.

### 2. Voice of Customer

Inspect actual interviews, reviews, sales conversations, research, objections, and testimonials. Preserve the buyer's wording and context. Distinguish direct quotation, paraphrase, and interpretation; never turn an invented example into a customer finding.

Record who was studied, relevant audience attributes, recency, repeated patterns, contradictions, and limitations. Do not call a pattern representative without a basis.

Return needs, motivations, stakes, language, objections, contrary evidence, and implications for the narrative.

### 3. Competitive Narrative

Compare documented competitor positioning, story, change claim, audience, method, proof, and product contribution. Include actual non-vendor alternatives when relevant. Distinguish present capabilities from roadmaps and company claims from independently established outcomes.

Return common conventions, useful points of contrast, potential narrative territories, sources and dates, and the strongest credible counterargument. Do not mistake a different tagline for a different strategy.

## Design modes

### 4. Build

Establish the brief and positioning foundation. Select the arc before polishing: use the five-stage argument for a change-led narrative, or the labeled reframe-led alternative when an external change is not established. Turn the new game into practical actions and success criteria; connect obstacles to delivered product mechanisms and proof.

For a full build, return:

1. Strategic thesis, audience, and business objective.
2. Narrative in the selected arc, clearly identified in working notes.
3. New-game definition, actions, success criteria, and fair old-versus-new comparison.
4. Product mechanism and evidence mapping, highlighting gaps.
5. Concise narrative summary.
6. Five-slide outline, when requested or useful: one principal idea, proof or visual suggestion, and transition per slide.
7. Critical risks, readiness, validation priorities, and practical GTM implications.

Label provisional choices. Do not describe the result as approved or commercially validated because the argument reads well.

### 5. Workshop

Adapt facilitation to the audience's experience and time. Establish the decision, share evidence, explore alternatives, work through the five stages, surface disagreements, and summarize decisions and unresolved questions. Distinguish a facilitator's recommendation from a group decision.

Use the following explicit protocol when the user says **Question Mode**.

#### Question Mode protocol

Collect five topics in this order:

1. **What are you working on?** Establish the company, product, initiative, or story and the objective.
2. **Who are you trying to reach?** Establish the primary audience and the decision or behavior to influence.
3. **What's changing in their world?** Establish the external shift and available evidence.
4. **How should they adapt, and what's stopping them?** Explore the new approach and its barriers.
5. **How does your offering help them succeed?** Establish current capabilities, outcomes, proof, and limits.

Use the existing brief to fill topics already answered; do not make the user repeat themselves. Ask the first unanswered question, one at a time, and wait for the answer. Tailor wording and brief follow-ups to what was said. Do not dump all five questions or draft the narrative after the first answer.

Once all five topics are addressed, select the supported arc and synthesize a draft, showing important hypotheses and gaps. If no external shift is established, use the labeled reframe-led alternative or retain a provisional change hypothesis. Recommend the next step. If the user cannot answer a topic, record it as unknown and continue; do not invent the answer. If the user asks to exit, summarize what is known and switch modes. An explicit request to draft immediately overrides the waiting sequence; preserve unknowns visibly.

### 6. Narrative Alternatives

Develop at least three materially different directions when this mode is requested. Vary the underlying insight, audience stakes, or response; avoid presenting synonymous headlines as strategies.

Compare thesis, audience, change, new game, product fit, evidence, distinctiveness, commercial relevance, vulnerabilities, and cost of adoption. Recommend a direction with reasons and conditions that would change the recommendation. Keep names provisional until methods and comprehension are sound.

## Challenge modes

### 7. Pressure Test

Read the pressure-test reference and apply all twelve tests for a full review. Find central contradictions before grading expression.

Return a concise verdict, consequential findings with severity, prioritized repairs, a revised core argument where useful, and the next validation step. Include the anchored scorecard only when requested; combine objections and assumptions with the findings they inform. Give an Advance/Refine/Rebuild recommendation for the defined use. Connect Advance to the next defined use, not a blanket permission to launch.

### 8. Audience Simulation

Simulate plausible reactions from relevant buyers, users, executives, practitioners, and competitors. Include unfamiliar prospects and skeptical stakeholders where useful. Ground each perspective in the brief rather than stereotypes.

Label every simulated response as a hypothesis. Return likely comprehension, objections, points of recognition, and questions to test with real people. Do not invent interviews, quotes, or customer consensus.

### 9. Narrative Experiment

Define a falsifiable question, audience, exposure, comparison, desired learning, observable signals, and decision rule. Prioritize the weakest strategic or evidentiary link. Use appropriate interviews, comprehension and recall tests, conversation trials, comparative messages, or campaign experiments.

Return a proportionate plan with baseline, measurement, confounders, practical responsibilities when known, and a clear consequence for each possible result. Do not present arbitrary thresholds as established benchmarks.

## Refinement modes

### 10. Refine

Diagnose strategic, evidentiary, persuasive, and editorial issues. Repair the earliest broken causal link and preserve useful material. Use targeted edits when sufficient. Explain significant changes to positioning, audience, method, product promise, or evidence.

Return revised work, a short explanation of consequential changes, and any remaining material concern. Match the depth to the request.

### 11. Writing Voice Calibration — Optional

Use personal voice calibration when requested or already established in the conversation. Use representative authorized samples and an available writing-style workflow; if no workflow is available, use supplied examples. Distinguish observed choices from assumptions. Let the current task and its audience control facts and format.

Until calibrated, use clear, direct, conversational business writing. Preserve specificity, useful rhythm, and natural repetition; do not mimic a personality from thin evidence.

### 12. Say-Aloud Review

Read the writing reference. Assess likely spoken flow, clarity, rhythm, transitions, audience recognition, and credibility. If audio is absent, do not claim literal listening or verified emotional response.

For a full spoken review, return a verdict, problematic passages with reasons, revised copy, and remaining concerns. For a narrow edit, return the improved wording and only essential notes. Recommend a human read-aloud for important presentations without claiming it has occurred.

## Activation mode

### 13. Activate

Establish the foundation's actual decision status, target audience, channel, purpose, and product/evidence boundaries. Adapt emphasis to the format while preserving the underlying argument.

For substantial activation, return the foundation and status, core message and audience-specific support, finished content, proof requirements, consistency check, and a practical action/learning plan. Distinguish proposed owners from confirmed ones.

Use authorized destination and artifact workflows. Do not publish, send, or edit an external source solely because the narrative has passed a quality review. Do not request fresh permission where the user has already authorized the action.

## Output sizing

Use the full contracts for substantial projects and explicit full reviews. For a headline, paragraph, short script, or limited edit, preserve the strategic foundation and run checks quietly. Return usable work first. Avoid repeating the same finding in the verdict, scorecard, objections, repairs, and conclusion.
