# Pressure tests and validation

## Contents

- Twelve pressure tests
- Severity and repair
- Anchored scorecard
- Readiness and real-world validation

## Twelve pressure tests

Apply every test for a full Narrative Design Pressure Test. Use relevant tests for smaller tasks. For the labeled reframe-led alternative, assess the opening contradiction and audience evidence in place of an unestablished market shift; mark change-specific questions not applicable and never invent history to pass a test. Support findings with passages, evidence, or specific missing links.

| Test | Questions to investigate |
| --- | --- |
| 1. Change validity | Is the shift external, meaningful, timely, and evidenced? Is a possibility being passed off as widespread behavior? |
| 2. Audience relevance | Who experiences the change, in which situation, and why does it affect a real decision? Are stakes specific and proportionate? |
| 3. Differentiation | Could a competitor use the same argument unchanged? Where does interpretation, method, mechanism, or proof create a relevant difference? |
| 4. New-game strength | Can a practitioner explain and apply the approach without buying the product? Are actions, success, and trade-offs clear? |
| 5. Narrative logic | Does change justify impact, impact motivate the approach, and that approach establish real barriers the product addresses? |
| 6. Customer empathy | Does the story reflect customers' actual work and constraints? Does it acknowledge rational reasons to maintain current practice? |
| 7. Solution credibility | Can delivered capabilities produce the claimed result under stated conditions? Are prototype and future promises separated? |
| 8. Persuasion | Are ethos, pathos, and logos present as credibility, human relevance, and sound reasoning? Is emotion earned through specificity? |
| 9. Commercial connection | Which buyer priority and business outcome matter? Is the adoption and value mechanism plausible after costs and effort? |
| 10. Competitive counterattack | What is the strongest credible response from a competitor, incumbent, internal builder, or proponent of doing nothing? |
| 11. Executive challenge | Would leadership, finance, product, and sales accept the strategic choice, implementation requirements, and product/evidence boundaries? |
| 12. Customer comprehension | Can an unfamiliar prospect explain the change, approach, product contribution, and next action without being coached? |

Do not reject a common market change merely because competitors recognize it. Challenge whether the interpretation and proposed response create relevant advantage. Do not insist on novelty where a clear, useful, credible story is the objective.

Include relevant skeptical voices: customer, unfamiliar prospect, CEO, CFO, product leader, sales leader, competitor, and experienced practitioner. Label simulated objections as hypotheses, not recorded feedback.

## Severity and repair

- **Critical:** A central promise contradicts known product reality, the argument depends on fabricated/contradicted evidence, or the main causal premise fails. Rebuild the affected argument; do not offset it with strong prose or a high total.
- **Major:** An important claim, audience choice, differentiator, method, or causal transition lacks support or substance. Repair before claiming readiness for the intended use.
- **Moderate:** A specific ambiguity, missing supporting example, weak transition, or insufficiently developed implication reduces understanding. Make a targeted repair.
- **Minor:** A localized expression, repetition, or rhythm issue. Edit without reframing the strategy unnecessarily.

Separate a missing input from evidence of failure. Describe what is unknown and what would establish it. Preserve a useful draft with visible uncertainty.

Repair in this order:

1. Identify the weakest causal link and earliest invalid assumption.
2. Classify the problem: strategic, evidentiary, persuasive, or editorial.
3. Correct the foundation and affected downstream stages.
4. Recheck the strongest objections and product limits.
5. Restore flow, specificity, and human relevance.
6. Apply no-slop and say-aloud checks.
7. Check consistency with the established foundation.

Recommend **Advance**, **Refine**, or **Rebuild** and name the next use or decision. Advance may mean advancing to an interview or pilot; it does not automatically mean public launch.

## Anchored scorecard

Use this scorecard only when requested. For a reframe-led narrative without a market-change claim, mark Change credibility Not applicable and do not total the score.

Treat this as an internal diagnostic extension, not Andrews' official rubric or a validated predictor of revenue. Grade the argument on the evidence actually available. Give a short rationale per dimension. Use 2 or 4 for intermediate performance.

| Dimension | 1 — weak | 3 — provisional | 5 — strong within stated scope |
| --- | --- | --- | --- |
| Change credibility | Generic, unsupported, or contradicted | Specific plausible shift; incomplete support | Precise, timely shift supported by relevant evidence and bounded claims |
| Audience relevance and stakes | Audience or consequence unclear | Defined audience; plausible stakes with gaps | Specific decisions and consequences grounded in relevant audience evidence |
| New-game differentiation | Product slogan or unsubstantiated novelty | Useful approach; distinction or method incomplete | Practical method, clear contrast, and evidenced relevance against alternatives |
| Customer obstacle realism | Invented, insulting, or reverse-engineered | Plausible barriers; limited customer grounding | Important barriers, costs, and trade-offs supported in the target context |
| Solution credibility | Promise exceeds capability | Mechanism plausible; material proof gaps disclosed | Delivered mechanisms and suitable evidence support bounded outcomes |
| Persuasive strength | Hype or disconnected assertions | Coherent reasoning; uneven credibility or human stakes | Credible, relevant argument with proportionate evidence and a serious counterargument |
| Clarity and narrative flow | Confusing or jargon-led | Understandable with some explanation | Clear causal flow and retellable core idea; audience testing supports stronger comprehension claims |

If there is insufficient information, mark the dimension **Not assessable** and explain what is missing. Do not fabricate a number. Sum out of 35 only when all seven dimensions are assessable; otherwise show the assessed dimensions without a normalized total.

- **28–35:** Strong structural candidate for the next validation or scoped activation step.
- **19–27:** Promising argument with meaningful repairs needed.
- **7–18:** Substantial strategic reconstruction needed.

Let critical failures override totals. Do not interpret these thresholds as probabilities, scientific benchmarks, customer endorsement, or approval. Do not raise a score merely because the assistant rewrote the prose.

## Readiness and real-world validation

Keep distinct: working draft; ready for audience testing; human-approved for a defined use; tested with a specified audience. A narrative can be approved but untested, tested but unapproved, or comprehensible without demonstrated commercial benefit.

Match validation to the claim and decision:

| Question | Useful test | What it does not establish alone |
| --- | --- | --- |
| Do buyers recognize the change and stakes? | Interviews about recent behavior and decisions, including contrary cases | Market prevalence or revenue causality |
| Do people understand and remember it? | Unprompted explanation, recall, and identification of next action | Purchase intent or product performance |
| Is the approach useful and distinct? | Compare it with actual alternatives using comparable exposures | Exclusive ownership or long-term defensibility |
| Can the product deliver? | Bounded workflow or product evaluation using realistic conditions | Universal results or performance in untested settings |
| Does messaging affect behavior? | Suitable comparison or experiment against a baseline | Revenue attribution without appropriate design and controls |
| Can teams use it consistently? | Asset review, sales conversation trials, and internal adoption evidence | External buyer acceptance |

Specify the hypothesis, audience, method, evidence that supports or falsifies it, limitations, and the resulting decision. Define thresholds proportionate to the situation; label proposed thresholds as choices rather than established standards. Seek disagreement and missed cases, not only favorable reactions.

For commercial measurement, record the baseline, comparison, timing, other changes, and attribution limits. Distinguish leading signals such as comprehension or qualified engagement from downstream pipeline, conversion, adoption, and revenue.

Keep testing practical. Do not demand an exhaustive research program before an exploratory draft, a clearly scoped prototype invitation, or a labeled thought-leadership hypothesis. Explain what claims each can credibly make now.
