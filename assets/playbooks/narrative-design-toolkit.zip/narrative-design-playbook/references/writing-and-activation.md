# Writing and activation

## Contents

- No AI slop
- Say-aloud and human resonance review
- Messaging and execution
- Canonical integrity and maintenance
- Final delivery

## No AI slop

Apply the standard to narrative drafts, presentations, campaigns, memos, scripts, and copy. Prefer specificity and sound reasoning over superficial brevity.

Remove generic thought-leadership openings, unsupported sweeping statements, empty jargon, overblown promises, pointless adjectives, forced metaphors, clichéd contrasts, mechanical three-part lists, predictable rhythms, unnecessary rhetorical questions, repetitive explanations, vague benefits, and generic conclusions.

Do not ban every adjective, list of three, contrast, metaphor, question, or repeated phrase. Preserve rhetorical choices that earn their place through meaning, rhythm, and audience relevance. Keep fair old-versus-new comparisons useful rather than theatrical.

Apply the sentence value test. Require each sentence to do at least one useful job:

- Introduce a meaningful fact or observation.
- Advance the argument or establish a point of view.
- Explain a consequence or practical mechanism.
- Provide relevant evidence.
- Clarify complexity.
- Create authentic human recognition or connect ideas.

Remove or revise sentences without a useful role. Do not make writing artificially terse, aggressive, or dramatic. Preserve qualifications that materially affect truth. Do not replace a precise technical term with a vague everyday word.

Use active verbs, familiar language, concrete examples, and natural variation in sentence length. Let emphasis follow the reasoning. Apply requested or established writing-style preferences using authorized samples. Otherwise use clear, direct business writing.

## Say-aloud and human resonance review

Assess likely spoken performance from text when no audio is supplied. Never claim literal listening, verified emotional response, or customer comprehension from an internal reading.

| Dimension | Check |
| --- | --- |
| Breath | Can a person comfortably say the sentence? Can long clauses be simplified without losing substance? |
| Rhythm | Is there useful variation rather than monotonous short statements or overlong clauses? |
| Flow | Does each idea lead naturally to the next? Are causal connections explicit enough? |
| Clarity | Can a listener understand on first hearing, without rereading a pronoun or technical phrase? |
| Authenticity | Would a thoughtful person speak this way in the relevant setting? |
| Resonance | Will this audience recognize its goals, frustrations, constraints, or ambitions? |
| Memorability | Is there a specific idea worth retaining, rather than only a catchy phrase? |
| Credibility | Does the speaker explain what they mean and acknowledge necessary limits? |

Flag awkward clauses, overloaded sentences, repeated transitions, abrupt jumps, unexplained jargon, weak pronouns, forced emotion, and likely attention loss. Rewrite while preserving substance and appropriate nuance.

For human resonance, ask whether the story reflects recognizable work, a believable tension, meaningful stakes, genuine empathy, and a practical implication. Do not manufacture anxiety or assume resonance without testing. Recommend a human read-aloud for important scripts and presentations.

## Messaging and execution

Translate a substantial approved or provisional foundation into an appropriate message system:

1. State the audience, buying situation, communication objective, and actual decision status.
2. Define the core promise or thesis.
3. State supporting messages and differentiated mechanisms.
4. Attach proof and the boundaries of each claim.
5. Address important objections and actual alternatives.
6. Define the relevant next action.

Adapt emphasis rather than creating a different underlying story for each audience. A technical approver may need mechanisms and controls; an executive may need strategic consequences; a user may need a concrete task and benefit. Do not replace the core argument with generic persona stereotypes.

For a five-slide narrative, use one main idea per change-led stage, relevant evidence or a concrete example, and a natural transition. Treat this as a narrative prototype, not a complete sales or investor presentation. Add the discovery, product detail, proof, economics, and next steps the actual presentation requires.

Use channel judgment:

| Output | Practical emphasis |
| --- | --- |
| Homepage | Immediate comprehension, relevant value, proof, and next action; do not force a long market lecture above the fold. |
| Sales pitch | The buyer's situation, reason to change, alternatives, approach, product mechanism, proof, and next step. |
| Product launch | Show how the shipped change advances the established narrative and what customers can do now. |
| Executive thought leadership | A defensible point of view, evidence, implications, counterargument, and useful recommendation. |
| Customer education | Help practitioners apply the method, including constraints and examples. |
| Internal enablement | Explain the strategic choices, approved claims, proof, objections, and how teams should use them. |

For substantial activation, specify assets, audience, known or proposed owner, channel, next action, and one or more proportionate learning measures. Connect choices to commercial goals without inventing targets or claiming attribution.

Build authority through useful education, frameworks, implementation guidance, tools, case evidence, and continued learning. Recommend only the activities that serve the goal and available resources. Do not prescribe a certification, community, or large content program by default.

## Canonical integrity and maintenance

When a narrative is intended for reuse, maintain a compact foundation:

| Field | Record |
| --- | --- |
| Identity | Name, scope, version/date, source location if available |
| Governance | Owner, decision maker, actual decision status, approved uses if known |
| Strategy | Primary audience, objective, positioning foundation, thesis, argument in the selected arc |
| Method | New-game definition, practical actions, success criteria, trade-offs |
| Truth | Delivered product scope, supporting evidence and dates, limitations, open hypotheses |
| Expression | Core messages, terminology, reusable proof, and prohibited or unsupported promises |
| Learning | Validation method, audience, findings, scope, next review trigger |

Use only fields that help the task; do not add a governance table to every paragraph edit. Mark absent information unknown rather than inventing it. Keep the foundation as a proposed draft until its actual status is established.

For adaptations, check market change, audience, consequences, method, obstacles, product role, proof, and terminology. Flag contradictions, unsupported new promises, or a material change in positioning. Allow appropriate channel and audience variation.

Honor existing human decisions and authorization. Do not silently overwrite an approved foundation or claim that the assistant has approved it. Do not turn internal quality checks into a new permission requirement for already authorized work.

Revisit the strategy when the premise, audience, alternatives, differentiated value, or product contribution materially changes. Refresh examples and evidence when those alone change. State the reason and scope of a proposed revision.

## Final delivery

Lead with the requested usable work or the central verdict. Explain only consequential changes and remaining weaknesses. Surface evidence gaps in review notes without littering audience-facing copy with process language.

For a major narrative, check strategy, logic, customer relevance, product truth, evidence, differentiation, implementation, no-slop, spoken flow, and canonical consistency. Do not hide failed checks behind polished copy.

Make the story easy to understand, retell, and act on. Keep each recommendation concrete enough for a PMM, product team, marketer, or seller to use.
